import forgecord

forgecord.start('config.json')
